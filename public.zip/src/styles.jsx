export const breakpoints = {
  mobile: "@media (max-width: 800px)",
  laptop: "@media (min-width: 800px)"
};
